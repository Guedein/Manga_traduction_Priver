def __init__(self):
    self.pipeline = None
